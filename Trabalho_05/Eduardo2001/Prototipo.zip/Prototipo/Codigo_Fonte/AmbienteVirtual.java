// Prot�tipo de um Ambiente Virtual Distribu�do
//
// Implementa��o resultante do TCC da 
// primeira fase do ano de 2001
//
// Acad�mico: Vandeir Eduardo
// Prof. orientador: Dalton Solano dos Reis

//import de subclasses awt e swing (componentes visuais da interface gr�fica)
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
//import de subclasses java.net para utiliza��o de classes
//relacionadas com a rede
import java.net.*;
//import de classes do Java3D
import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.picking.behaviors.*;
import com.sun.j3d.utils.behaviors.keyboard.KeyNavigatorBehavior;
import com.sun.j3d.utils.behaviors.mouse.*;
import javax.media.j3d.*;
import javax.vecmath.*;
//classes de utilidade geral do java
import java.util.*;
//import das classes do DIS-Java-VRML
import mil.navy.nps.util.*;
import mil.navy.nps.dis.*;
import mil.navy.nps.disEnumerations.*;

//Classe para controle e cria��o da tabela (da inteface gr�fica) de usu�rios
class PainelInfoUsuarios extends AbstractTableModel {
	//atributos gerais da tabela (nro. de colunas,
	//nro. de linhas, nome da colunas, conte�do da tabela, etc)
	protected static int numColunas = 9;
    protected static int numColunasInicial = 5;
    protected int proxLinhaVazia = 0;
    protected int numLinhas = 0;

    static final public String idName = "Aplica��o";
    static final public String coordXName = "Pos. X";
    static final public String coordYName = "Pos. Y";
    static final public String coordZName = "Pos. Z";
	static final public String qtdeEspduName = "ESPDU Rec.";
	static final public String qtdeFirepduName = "FirePDU Rec.";
	static final public String qtdeRepduName = "REPDU Rec.";
	static final public String qtdeCepduName = "CEPDU Rec.";
	static final public String qtdeColipduName = "ColiPDU Rec.";

    protected Vector data = null;

    public PainelInfoUsuarios() {
        data = new Vector();
    }

    //retorna o nome das colunas da tabela
	public String getColumnName(int column) {
        switch (column) {
          case 0:
            return idName;
          case 1:
            return coordXName;
          case 2:
            return coordYName;
          case 3:
            return coordZName;
		  case 4:
			return qtdeEspduName;
		  case 5:
			return qtdeFirepduName;
		  case 6:
			return qtdeRepduName;
		  case 7:
		    return qtdeCepduName;
		  case 8:
		    return qtdeColipduName;
        }
        return "";
    }

    //retorna o n�mero de colunas
	public synchronized int getColumnCount() {
        return numColunas;
    }

    //retorna o n�mero de linhas
	public synchronized int getRowCount() {
        if (numLinhas < numColunasInicial) {
            return numColunasInicial;
        } else {
            return numLinhas;
        }
    }

    //retorna o valor de uma c�lula da tabela
	public synchronized Object getValueAt(int row, int column) {
        try {
            Vector vector = (Vector)data.elementAt(row);
            switch (column) {
              case 0:
                return new String((String)vector.elementAt(0));
              case 1:
                return new String((String)vector.elementAt(1));
              case 2:
                return new String((String)vector.elementAt(2));
              case 3:
                return new String((String)vector.elementAt(3));
			  case 4:
				return new String((String)vector.elementAt(4));
			  case 5:
				return new String((String)vector.elementAt(5));
			  case 6:
				return new String((String)vector.elementAt(6));
			  case 7:
			    return new String((String)vector.elementAt(7));
			  case 8:
			    return new String((String)vector.elementAt(8));
            }
        } catch (Exception e) {
        }
        return "";
    }

	//m�todo utilizado para modificar o conte�do da tabela
	public synchronized void updatePlayer(Vector infoUsuarios, String acao, String tipoPDU) {
		//Pega informa��o que identifica a linha a ser alterada
        String ID = (String)infoUsuarios.elementAt(0);
        Vector infoLinha;
        int index = -1; 
        boolean achou = false;
        boolean adicionouLinha = false;
		boolean removeuLinha = false;
        
        int i = 0;
		//Procura a linha correspondente na tabela
        while (!achou && (i < proxLinhaVazia)) {
            infoLinha = (Vector)data.elementAt(i);
            if (((String)infoLinha.elementAt(0)).compareTo(ID) == 0) {
                achou = true;
                index = i;
            } else {
                i++;
            }
        }
	
		//Se achou a linha e � para remover a linha
		if ((achou) && (acao == "Remover")) {
			data.removeElementAt(index);
			numLinhas--;
			proxLinhaVazia--;
			if (proxLinhaVazia < 0)
				proxLinhaVazia = 0;
			removeuLinha = true;
		} else {
			if (achou) { 
				infoLinha = (Vector)data.elementAt(index);
				//N�o altera as coordenadas atuais da linha na tabela
				if (acao != "NaoAtualizarCoordenadas"){
					infoLinha.setElementAt(infoUsuarios.elementAt(1), 1);
					infoLinha.setElementAt(infoUsuarios.elementAt(2), 2);
					infoLinha.setElementAt(infoUsuarios.elementAt(3), 3);
				}
				//Se tipoPDU for igual a ESPDU incrementa o contador de ESPDU's recebidos
				//e assim por diante
				if (tipoPDU == "ESPDU") {
					Integer qtdeEspdu = new Integer((String)infoLinha.elementAt(4));
					Integer soma = new Integer(qtdeEspdu.intValue() + 1);
					infoLinha.setElementAt(soma.toString(), 4);

				}
				if (tipoPDU == "FRPDU") {
					Integer qtdeFrpdu = new Integer((String)infoLinha.elementAt(5));
					Integer soma = new Integer(qtdeFrpdu.intValue() + 1);
					infoLinha.setElementAt(soma.toString(), 5);

				}
				if (tipoPDU == "REPDU") {
					Integer qtdeRepdu = new Integer((String)infoLinha.elementAt(6));
					Integer soma = new Integer(qtdeRepdu.intValue() + 1);
					infoLinha.setElementAt(soma.toString(), 6);

				}
				if (tipoPDU == "CEPDU") {
					Integer qtdeCepdu = new Integer((String)infoLinha.elementAt(7));
					Integer soma = new Integer(qtdeCepdu.intValue() + 1);
					infoLinha.setElementAt(soma.toString(), 7);
				}
				if (tipoPDU == "CLPDU") {
					Integer qtdeColipdu = new Integer((String)infoLinha.elementAt(8));
					Integer soma = new Integer(qtdeColipdu.intValue() + 1);
					infoLinha.setElementAt(soma.toString(), 8);
				}
				data.setElementAt(infoLinha, index);
			} else {
				//acrescenta nova linha na tabela, usu�rio novo
				if (numLinhas <= proxLinhaVazia) {
					numLinhas++;
					adicionouLinha = true;
				}
				index = proxLinhaVazia;
		        proxLinhaVazia++;
				infoUsuarios.addElement("0");
				infoUsuarios.addElement("0");
				infoUsuarios.addElement("0");
				if (tipoPDU == "CEPDU")
					infoUsuarios.addElement("1");
				else
					infoUsuarios.addElement("0");
				infoUsuarios.addElement("0");
				data.addElement(infoUsuarios);
			}
        }
    
		//Chama o m�todo correspondente de acordo com a atualiza��o
		//que houve na tabela (nova linha, linha removida ou s� altera��o de dados)
        if (adicionouLinha) {
            fireTableRowsInserted(index, index);
        } else {
			if (removeuLinha) {
				fireTableRowsDeleted(index, index);
			} else {
				fireTableRowsUpdated(index, index);
			}
		}
    }

	//Limpa o conte�do da tabela
	public synchronized void clear() {
        int oldNumRows = numLinhas;

        numLinhas = numColunasInicial;
        data.removeAllElements();
        proxLinhaVazia = 0;

        if (oldNumRows > numColunasInicial) {
            fireTableRowsDeleted(numColunasInicial, oldNumRows - 1);
        }
        fireTableRowsUpdated(0, numColunasInicial - 1);
    }
}

//Classe para tratamento das teclas pressionadas durante a
//utiliza��o do prot�tipo
class TrataTecladoBehavior extends KeyAdapter {
	private AmbienteVirtual pai;
	private short qtdeEntidadesApp;
	private TransformGroup tg;
	private TransformGroup tgColisao = new TransformGroup();
	private Transform3D t3d = new Transform3D();
	private Transform3D t3dColisao = new Transform3D();
	private Vector3d v3d = new Vector3d();
	private double coordenadas[] = new double[3];
	private EntityStatePdu esPDU = new EntityStatePdu();
	private BehaviorStreamBufferUDP bsb2;
	private short siteId;
	private short appId;
	private UnsignedInt tipoEntidade;

	TrataTecladoBehavior (AmbienteVirtual pt, TransformGroup tg) {
		pai = pt;
		this.tg = tg;
		bsb2 = pai.getBehaviorStreamBuffer();
	}

	//m�todo invocado sempre que uma tecla � pressionada
	public void keyPressed(KeyEvent k) {
		int c = k.getKeyCode();
		qtdeEntidadesApp = pai.getQtdeEntidadesApp();
		//s� trata as teclas depois que o usu�rio entrou no AV
		if (qtdeEntidadesApp > 0) {
			tg.getTransform(t3d);
			t3d.get(v3d);
			v3d.get(coordenadas);
			boolean estaColidindo = false;
	        switch (c) {
				//caso seta esquerda
				case KeyEvent.VK_LEFT:
					pai.setUltimaTeclaPressionada("esquerda");
					if (pai.getDirecaoColisao() != "esquerda") {
						coordenadas[0] -= 0.05; //-0.05m na coordenada do eixo X
					} else {
						estaColidindo = true;
						System.out.println("TrataTecladoBehavior:keyPressed():Est� colidindo na esquerda");
					}
					break;
				//caso seta direita
				case KeyEvent.VK_RIGHT:
					pai.setUltimaTeclaPressionada("direita");
					if (pai.getDirecaoColisao() != "direita") {
						coordenadas[0] += 0.05; //+0.05m na coordenada do eixo X
					} else {
						estaColidindo = true;
						System.out.println("TrataTecladoBehavior:keyPressed():Est� colidindo na direita");
					}
					break;
				//caso page down
				case KeyEvent.VK_PAGE_DOWN:
					pai.setUltimaTeclaPressionada("baixo");
					if (pai.getDirecaoColisao() != "baixo") {
						coordenadas[1] -= 0.05; //-0.05m na coordenada do eixo Y
					} else {
						estaColidindo = true;
						System.out.println("TrataTecladoBehavior:keyPressed():Est� colidindo pra baixo");
					}
					break;
				//caso page up
				case KeyEvent.VK_PAGE_UP:
					pai.setUltimaTeclaPressionada("cima");
					if (pai.getDirecaoColisao() != "cima") {
						coordenadas[1] += 0.05; //+0.05m na coordenada do eixo Y
					} else {
						estaColidindo = true;
						System.out.println("TrataTecladoBehavior:keyPressed():Est� colidindo pra cima");
					}
					break;
				//caso seta pra cima
				case KeyEvent.VK_UP:
					pai.setUltimaTeclaPressionada("dentro");
					if (pai.getDirecaoColisao() != "dentro") {
						coordenadas[2] -= 0.05; //-0.05m na coordenada do eixo Z
					} else {
						estaColidindo = true;
						System.out.println("TrataTecladoBehavior:keyPressed():Est� colidindo pra dentro");
					}
					break;
				//caso seta pra baixo
				case KeyEvent.VK_DOWN:
					pai.setUltimaTeclaPressionada("fora");
					if (pai.getDirecaoColisao() != "fora") {
						coordenadas[2] += 0.05; //+0.05m na coordenada do eixo Z
					} else {
						estaColidindo = true;
						System.out.println("TrataTecladoBehavior:keyPressed():Est� colidindo pra fora");
					}
					break;
				//caso barra de espa�os
				case KeyEvent.VK_SPACE:
					//se j� n�o estiver atirando
					if (!pai.getAtirando()) {
						pai.setAtirando(true);
						disparaTiro(coordenadas);
					}
					break;
			}
			//se n�o estiver colidindo, aplica as novas coordenadas
			if (!estaColidindo) {
				v3d.set(coordenadas);
				t3d.set(v3d);
				tg.setTransform(t3d);
				informaAtualizacao(t3d, v3d);
				pai.atualizaMostradorPosicao(coordenadas);
			}
		}
    }

	//m�todo utilizado para criar um ESPDU e envi�-los aos demais
	//usu�rios, afim de informar sobre a nova localiza��o dessa entidade
	public void informaAtualizacao(Transform3D t3d, Vector3d v3d) {
		siteId = pai.getSiteId();
		appId = pai.getAppId();
		tipoEntidade = pai.getTipoEntidade();
		//insere as informa��es que identificam essa entidade no ESPDU
		esPDU.setEntityID(siteId,appId,(short)1);
		esPDU.setEntityAppearance(tipoEntidade);
		t3d.get(v3d);
		//insere as informa��es que determinam as novas coordenadas dessa entidade
		esPDU.setEntityLocationX(v3d.x);
		esPDU.setEntityLocationY(v3d.y);
		esPDU.setEntityLocationZ(v3d.z);
		esPDU.setExemplar(esPDU);
		bsb2.setTimeToLive(15);
		Thread enviadorPDU = new Thread(bsb2);
		//envia ESPDU aos demais usu�rios
		bsb2.sendPdu(esPDU.getExemplar(), pai.getEndBroadCast(), 8133);
		//System.out.println("TrataTecladoBehavior:informaAtualizacao():Novas coordenadas: X:" + v3d.x + " Y: "+ v3d.y +" Z: "+v3d.z);
	}

	//m�todo utilizado para criar um FirePDU e enviar para os demais
	//usu�rios informando acerca da ocorr�ncia do disparo e localiza��o
	//do mesmo
	public void disparaTiro(double[] coord) {
		siteId = pai.getSiteId();
		appId = pai.getAppId();
		qtdeEntidadesApp = pai.getQtdeEntidadesApp();
		FirePdu frPDU = new FirePdu();
		//inclui informa��o que identifica o tiro
		frPDU.setFiringEntityID(new EntityID(siteId,appId,(short)(qtdeEntidadesApp+1)));
		//inclui informa��o que identifica a coordenada do tiro
		frPDU.setLocationInWorldCoordinate(coord[0], coord[1], coord[2] - 0.6d);
		if (bsb2 == null) {System.out.println("bsb2 no DISPARATIRO � null");}
		bsb2.setTimeToLive(15);
		Thread enviadorPDU = new Thread(bsb2);
		//envia FirePDU aos demais usu�rios
		bsb2.sendPdu((FirePdu)(frPDU.clone()), pai.getEndBroadCast(), 8133);
		pai.criaTiroLocal(frPDU);
	}

}

//classe respons�vel por implementar o mecanismo de Heartbeat
//que faz com que cada entidade do AV envie um ESPDU
//obrigatoriamente a cada 5 segundos, independente de ter
//havido mudan�a de estado ou n�o
class HeartBeatBehavior extends Behavior {
	private TransformGroup tg;
	private Transform3D t3d = new Transform3D();
	private Vector3f v3f = new Vector3f();
	private EntityStatePdu esPDU = new EntityStatePdu();
	private BehaviorStreamBufferUDP bsb2;
	private short qtdeEntidadesApp;
	private short siteId;
	private short appId;
	private UnsignedInt tipoEntidade;
	private AmbienteVirtual pai;

	HeartBeatBehavior (TransformGroup tg, AmbienteVirtual pt) {
		this.tg = tg;
		pai = pt;
		bsb2 = pai.getBehaviorStreamBuffer();
	}

	public void initialize() {
		//Seta o comportamento para ser disparado
		//depois que se passarem 5 segundos
		this.wakeupOn(new WakeupOnElapsedTime(5000));
	}

	//M�todo invocado pelo comportamento depois da passagem
	//dos 5 segundos
	public void processStimulus (Enumeration criteria) {
		tg.getTransform(t3d);
		qtdeEntidadesApp = pai.getQtdeEntidadesApp();
		//s� se o usu�rio tiver entrado no AV
		if (qtdeEntidadesApp > 0) {
			siteId = pai.getSiteId();
			appId = pai.getAppId();
			tipoEntidade = pai.getTipoEntidade();
			//inclui informa��es de identifica��o da entidade
			//e localiza��o no ESPDU
			esPDU.setEntityID(siteId,appId,(short)1);
			esPDU.setEntityAppearance(tipoEntidade);
			t3d.get(v3f);
			esPDU.setEntityLocationX(v3f.x);
			esPDU.setEntityLocationY(v3f.y);
			esPDU.setEntityLocationZ(v3f.z);
			esPDU.setExemplar(esPDU);
			bsb2.setTimeToLive(15);
			Thread enviadorPDU = new Thread(bsb2);
			//Envia ESPDU como resultado do Heartbeat
			bsb2.sendPdu(esPDU.getExemplar(), pai.getEndBroadCast(), 8133);
			System.out.println("HeartBeatBehavior:processStimulus(): HeartBeat executado, coordenadas X:"+ v3f.x +" Y: "+ v3f.y +" Z: "+ v3f.z);
		}
		//Engatilha o comportamento novamente, pros pr�ximos 5 segundos
		this.wakeupOn(new WakeupOnElapsedTime(5000));
	}
}

//classe respons�vel por realizar o processo de anima��o (deslocamento)
//da entidade que representa um tiro disparado
class AnimaTiroBehavior extends Behavior {
	private TransformGroup tg;
	private Transform3D t3d = new Transform3D();
	private Vector3d v3d = new Vector3d();
	private AmbienteVirtual pai;
	private double coordenadas[] = new double[3];
	private int range = 0;
	private boolean passou = false;
	private EntityID entityID;
	private BehaviorStreamBufferUDP bsb2;
	private short siteId;
	private short appId;
	private long entityId;
	private EntityStatePdu esPDU = new EntityStatePdu();

	AnimaTiroBehavior (AmbienteVirtual pt,TransformGroup tg) {
		this.tg = tg;
		pai = pt;
		bsb2 = pai.getBehaviorStreamBuffer();
	}

	public void initialize() {
		//Engatilha o comportamento para disparado depois de 10 ms
		this.wakeupOn(new WakeupOnElapsedTime(10));
	}

	//m�todo chamado sempre que o comportamento � disparado
	//nesse caso de 10 em 10ms
	public void processStimulus (Enumeration criteria) {
		//enquanto o tiro n�o tiver ultrapassado seu alcance
		if (range < 40) {
			tg.getTransform(t3d);
			t3d.get(v3d);
			v3d.get(coordenadas);
			coordenadas[2] -= 0.08;
			v3d.set(coordenadas);
			t3d.set(v3d);
			//aplica a mudan�a de coordenada no tiro
			tg.setTransform(t3d);
			informaAtualizacao(tg, v3d);
			//engatilha o comportamento novamente
			this.wakeupOn(new WakeupOnElapsedTime(10));
			range++;
		} else {
			//o tiro j� ultrapassou o alcance m�ximo e deve
			//ser removido do AV local, bem como ser enviado
			//um REPDU aos demais usu�rios para que os mesmos
			//tb removam a entidade que representa o tiro de
			//suas representa��es do AV
			System.out.println("AnimaTiroBehavior:processStimulus(): Tiro atingiu o alcance m�ximo");
			RemoveEntityPdu rePDU = new RemoveEntityPdu();
			EntityID tempEntityID = (EntityID)tg.getUserData();
			rePDU.setOriginatingEntityID(tempEntityID);
			//remove o tiro localmente
			pai.removeEntidade(rePDU);

			bsb2.setTimeToLive(15);
			Thread enviadorPDU = new Thread(bsb2);
			rePDU.setExemplar(rePDU);
			//envia um REPDU para que o tiro tb seja removido nos
			//demais usu�rios
			bsb2.sendPdu(rePDU.getExemplar(), pai.getEndBroadCast(), 8133);

			range = 0;
			pai.setAtirando(false);
			try {
				this.finalize();
			} catch (Throwable e) {System.out.println("Pau no finalize do AnimaTiro");}
		}
	}

	//m�todo utilizado para enviar ESPDU's aos demais usu�rios
	//atualizando-os sobre a movimenta��o do tiro
	public void informaAtualizacao(TransformGroup tg, Vector3d v3d) {
		entityID = (EntityID)tg.getUserData();
		siteId = pai.getSiteId();
		appId = pai.getAppId();
		entityId = entityID.getEntityID().longValue();
		//re�ne informa��es de identifica��o do tiro, bem como
		//de suas coordenadas
		esPDU.setEntityID(siteId,appId,(short)entityId);
		esPDU.setEntityLocationX(v3d.x);
		esPDU.setEntityLocationY(v3d.y);
		esPDU.setEntityLocationZ(v3d.z);
		esPDU.setExemplar(esPDU);
		bsb2.setTimeToLive(15);
		Thread enviadorPDU = new Thread(bsb2);
		bsb2.sendPdu(esPDU.getExemplar(), pai.getEndBroadCast(), 8133);
	}

}

//classe utilizada para controlar as entradas e sa�das
//de estado de colis�o das entidades
class CollisionBehavior extends Behavior {

	private TransformGroup tg;
	private AmbienteVirtual pai;
	private BehaviorStreamBufferUDP bsb2;

	CollisionBehavior (AmbienteVirtual pt, TransformGroup tg) {
		pai = pt;
		this.tg = tg;
		bsb2 = pai.getBehaviorStreamBuffer();
	}

	public void initialize() {
		//Engatilha esse comportamento para ser disparado quando a entidade
		//com a qual ele est� associado entrar ou sair de um estado de
		//colis�o com outra entidade
		WakeupCriterion[] wc = new WakeupCriterion[2];
		wc[1] = new WakeupOnCollisionEntry(tg, WakeupOnCollisionEntry.USE_GEOMETRY);
		wc[0] = new WakeupOnCollisionExit(tg, WakeupOnCollisionExit.USE_GEOMETRY);
		this.wakeupOn(new WakeupOr(wc));
	}

	public void processStimulus (Enumeration criteria) {
		while (criteria.hasMoreElements()) {
			Object proximoElemento = criteria.nextElement();
			//verifica qual foi o tipo de evento que disparou o comportamento
			//WakeupOnCollisionEntry = entrada de colis�o
			//ou WakeupOnCollisionExit = sa�da de colis�o
			//se foi entrada de colis�o...
			if (proximoElemento.getClass().getName().trim() == "javax.media.j3d.WakeupOnCollisionEntry") {
				System.out.println("CollisionBehavior:processStimulus(): Ocorr�ncia de entrada de colis�o ao pressionar a tecla: " + pai.getUltimaTeclaPressionada());
				//ativa estado de colis�o de acordo com a �ltima tecla pressionada
				pai.setDirecaoColisao(pai.getUltimaTeclaPressionada());				
				WakeupOnCollisionEntry entradaColisao = (WakeupOnCollisionEntry)proximoElemento;
				//o m�todo getTriggeringPath() retorna a ramifica��o do grafo de cena
				//correspondente ao n� que provocou a colis�o. Dessa forma � poss�vel
				//percorrer essa ramifica��o at� encontrar o TransformGroup da entidade
				//que colidiu e atrav�s do m�todo getUserData, ter acesso a identifica��o
				//da mesma
				for (int i = 0; i < entradaColisao.getTriggeringPath().nodeCount(); i++) {
					Object noTemporario = entradaColisao.getTriggeringPath().getNode(i);
					//de todos os n�s inseridos no grafo de cena, somente os TransformGroup's
					//das entidades tem a permiss�o EnableCollisionReporting habilitada, portanto ser�o
					//os �nicos cuja refer�ncia n�o ser� nula
					if (noTemporario != null) {
						TransformGroup tgTemp = (TransformGroup)noTemporario;
						EntityID collidingEntity = (EntityID)tgTemp.getUserData();
						EntityID issuingEntity = (EntityID)tg.getUserData();
						if (issuingEntity.getApplicationID().intValue() != collidingEntity.getApplicationID().intValue()) {
							informaColisao(issuingEntity, collidingEntity);
							System.out.println("CollisionBehavior:processStimulus(): Entidade da aplica��o: "+collidingEntity.getApplicationID()+" est� colidindo");
						}
					}
				}
			//se foi sa�da de colis�o...
			} else {
				System.out.println("CollisionBehavior:processStimulus(): Saiu da colis�o. Direcao de colisao resetada...");
				//reseta dire��o de colis�o
				pai.setDirecaoColisao("nula");
			}
		}
		//engatilha o comportamento novamente
		WakeupCriterion[] wc = new WakeupCriterion[2];
		wc[1] = new WakeupOnCollisionEntry(tg, WakeupOnCollisionEntry.USE_GEOMETRY);
		wc[0] = new WakeupOnCollisionExit(tg, WakeupOnCollisionExit.USE_GEOMETRY);
		this.wakeupOn(new WakeupOr(wc));
	}

	//m�todo utilizado para enviar um CollisionPDU aos demais
	//usu�rios informando acerca da ocorr�ncia da colis�o
	public void informaColisao(EntityID issuingEntity, EntityID collidingEntity) {
		CollisionPdu coliPDU = new CollisionPdu();
		coliPDU.setIssuingEntityID(issuingEntity);
		coliPDU.setCollidingEntityID(collidingEntity);
		bsb2.setTimeToLive(15);
		Thread enviadorPDU = new Thread(bsb2);
		bsb2.sendPdu((CollisionPdu)coliPDU.clone(), pai.getEndBroadCast(), 8133);
	}

}

//essa classe funciona como um "ouvidor" de PDU's
//fica aguardando o recebimento de PDU's atrav�s
//da rede, processando-os de acordo com o seu
//tipo
class TrataMovimentos extends Thread {
	private boolean vivo = true;
	private BehaviorStreamBufferUDP bsb;
	private AmbienteVirtual pai;
	private short tempId;
	private long ui;
	private long entApp;
	private short appId;

	TrataMovimentos (AmbienteVirtual pt, short id) {
		pai = pt;
		appId = id;
		bsb = new BehaviorStreamBufferUDP (8133);
		bsb.setDEBUG(false);
		Thread leitorPDU = new Thread(bsb);
		leitorPDU.start();
	}

	//m�todo �til para finalizar a Thread
	void setVivo (boolean vv) {
		System.out.println("TrataMovimentos:setVivo(): Thread processadora de PDU's recebidos finalizada");
		vivo = vv;
	}

	public void run () {
		while (vivo) {
			//passa os PDU's recebidos para um vetor
			java.util.Vector vetorPDU = bsb.receivedPdus();
			//percorre esse vetor de PDU's identificando o seu
			//tipo e executando a a��o correspondente a cada tipo
			for (Enumeration enum = vetorPDU.elements(); enum.hasMoreElements();) {
				ProtocolDataUnit tempPDU = (ProtocolDataUnit) enum.nextElement();
				UnsignedByte tipoPDU = tempPDU.getPduType();
				switch (tipoPDU.intValue()) {
					//caso PDU do tipo EntityState
					case PduTypeField.ENTITYSTATE : {
						EntityStatePdu tempESPDU = (EntityStatePdu) tempPDU;
						tempId = tempESPDU.getEntityID().getApplicationID().shortValue();
						entApp = tempESPDU.getEntityAppearance().longValue();
						//se n�o foi enviado por essa pr�pria aplica��o
						if (tempId != appId)
							pai.transladaEntidade(tempESPDU);
						break;
					}
					//caso PDU do tipo RemoveEntity
					case PduTypeField.REMOVEENTITY : {
						RemoveEntityPdu tempREPDU = (RemoveEntityPdu) tempPDU;
						tempId = tempREPDU.getOriginatingEntityID().getApplicationID().shortValue();
						if (tempId != appId) 
							pai.removeEntidade(tempREPDU);
						break;
					}
					//caso PDU do tipo CreateEntity
					case PduTypeField.CREATEENTITY : {
						CreateEntityPdu tempCEPDU = (CreateEntityPdu) tempPDU;
						tempId = tempCEPDU.getOriginatingEntityID().getApplicationID().shortValue();
						ui = tempCEPDU.getRequestID().longValue();
						double[] coordenadas = new double[3];
						//entidades novas s�o criadas nas coordenadas 0,0,0
						coordenadas[0] = 0;
						coordenadas[1] = 0;
						coordenadas[2] = 0;
						if (tempId != appId)
							pai.criaEntidadeRemota(tempCEPDU, coordenadas, ui);
						break;
					}
					//caso PDU do tipo Fire
					case PduTypeField.FIRE : {
						FirePdu tempFIPDU = (FirePdu) tempPDU;
						tempId = tempFIPDU.getFiringEntityID().getApplicationID().shortValue();
						if (tempId != appId)
							pai.criaTiroRemoto(tempFIPDU);
						break;
					}
					//caso PDU do tipo Collision
					case PduTypeField.COLLISION : {
						CollisionPdu tempColiPDU = (CollisionPdu) tempPDU;
						tempId = tempColiPDU.getIssuingEntityID().getApplicationID().shortValue();
						Integer tempIdInteger = new Integer(tempId);
						double[] coordenadas = new double[3];
						if (tempId != appId)
							//n�o executa nenhuma a��o significativa, somente
							//contabiliza o recebimento do mesmo
							pai.atualizaTabelaEntidades(tempIdInteger.toString(), coordenadas, "NaoAtualizarCoordenadas", "CLPDU");
						break;
					}
				}
			}
			//depois de processar um vetor de PDU's dorme 250ms
			try {
				Thread.sleep(250);
			} catch (Exception e) {
				System.out.println ("TrataMovimentos:run(): Problemas no sleep da Thread: " + e);
			}
		}
		bsb.shutdown();
		bsb.cleanup();
	}
}

public class AmbienteVirtual extends JFrame {
	//objeto para guardar intancia do universo principal
	private SimpleUniverse universo;
	//objetos de apar�ncia para os objetos visuais
	private Appearance ap1, ap2, ap3, ap4, ap5, ap6;
	//objeto canvas3D onde ser� renderizada as imagens do AV
	private Canvas3D canvas3d;
	//BranchGroup's principais do AV
	private BranchGroup bgRaiz, bgEntidades, bgTirosLocais, bgTirosRemotos, bgEntidadesRemotas;
	//Objetos para composi��o da interface visual
	private JPanel painelEsquerdo;
	private ButtonGroup rbGroup;
	private JRadioButton rbCaixa, rbCone, rbEsfera, rbCilindro;
	private JButton btEntrar, btSair, btFechar;
	private JTextField tfId, tfPosX, tfPosY, tfPosZ;
	private JTable table;
	//Objetos de defini��o de cores para serem utilizadas nas apar�ncias
	private ColoringAttributes cor1 = new ColoringAttributes(0.6f, 0.2f, 1.0f, 0);
	private ColoringAttributes cor2 = new ColoringAttributes(0.2f, 0.6f, 1.0f, 0);
	private ColoringAttributes cor3 = new ColoringAttributes(0.5f, 0.1f, 0.2f, 0);
	private ColoringAttributes cor4 = new ColoringAttributes(1.0f, 0.2f, 1.0f, 0);
	private ColoringAttributes cor5 = new ColoringAttributes(0.6f, 1.0f, 1.0f, 0);
	private ColoringAttributes cor6 = new ColoringAttributes(0.1f, 0.2f, 0.8f, 0);
	//guardar refer�ncia (utilizados em mais de um m�todo)
	private TrataMovimentos tm;
	private HeartBeatBehavior myHeartBeatBehavior;
	private TrataTecladoBehavior trataTecladoBehavior;
	//guarda a qtde de entidades representadas no AV local
	private short qtdeEntidadesApp = 0;
	//identifica��o do site
	private short siteId = 1;
	//identifica��o da aplica��o
	private short appId;
	//pra definir a forma da entidade (cone, caixa, cilindro, esfera)
	private UnsignedInt tipoEntidade;
	//armazena identifica��o da entidades remotas, tiros remotos e tiros locais,
	//respectivamente
	private List tabelaIdEntidadesRemotas = Collections.synchronizedList(new ArrayList());
	private List tabelaIdTirosRemotos = Collections.synchronizedList(new ArrayList());
	private List tabelaIdTirosLocais = Collections.synchronizedList(new ArrayList());
	//guarda �ltima tecla pressionada, dire��o de colis�o, estado de tiro ou n�o
	private String ultimaTeclaPressionada;
	private String direcaoColisao;
	private boolean estaAtirando = false;
	//utilizado para enviar PDU's
	private BehaviorStreamBufferUDP bsb = new BehaviorStreamBufferUDP(8134);
	//refer�ncia para tabela (interface gr�fica) dos usu�rios
	private PainelInfoUsuarios infoUsuarios;
	//objetos TransformGroup e Transform3D auxiliares
	private TransformGroup tgAux = new TransformGroup();
	private Transform3D t3dAux = new Transform3D();
	private TransformGroup tgAvatar;
	private TransformGroup transformGroupDeVisao;
	//endere�o de Brodcast da rede local
	private String endBroadCast = new String("255.255.255.255");

	//atualiza os mostrador das coordenadas da entidade local
	public void atualizaMostradorPosicao(double[] coord) {
		tfPosX.setText((new Float(coord[0])).toString());
		tfPosY.setText((new Float(coord[1])).toString());
		tfPosZ.setText((new Float(coord[2])).toString());
	}
	
	//retorna o endere�o de Broadcast configurado para essa aplica��o
	public String getEndBroadCast() {
		return endBroadCast;
	}

	//m�todo auxiliar para pegar refer�ncia ao objeto
	public BehaviorStreamBufferUDP getBehaviorStreamBuffer() {
		return bsb;
	}
	
	//utilizado para setar o estido de atirando ou n�o
	public void setAtirando(boolean estado) {
		estaAtirando = estado;
	}

	//retorna o estado de tiro
	public boolean getAtirando() {
		return estaAtirando;
	}
	
	//atacha desatacha BranchGroup de forma sincronizada (controle concorr�ncia)
	public synchronized void atachDetachBG(String acao, BranchGroup bg, BranchGroup bgPai) {
		if (acao == "atachar")
			if (bg.isLive())
				System.out.println("atachDetachBG(): Tentando atachar j� estando atachado.");
			else
				universo.addBranchGraph(bg);
		else
			if (!bg.isLive())
				System.out.println("atachDetachBG(): Tentando desatachar j� estando desatachado.");
			else
				bg.detach();
	}
	
	//para controle de colis�o
	public void setDirecaoColisao (String dirCol) {
		direcaoColisao = dirCol;
	}
	
	//para controle de colis�o
	public void setUltimaTeclaPressionada (String ultTecPres) {
		ultimaTeclaPressionada = ultTecPres;
	}

	public String getDirecaoColisao () {
		return direcaoColisao;
	}

	public String getUltimaTeclaPressionada () {
		return ultimaTeclaPressionada;
	}
	
	//conjunto de m�todos para ter acesso a alguns atributos
	//da classe principal
	public short getQtdeEntidadesApp() {
		return qtdeEntidadesApp;
	}

	public short getSiteId() {
		return siteId;
	}

	public short getAppId() {
		return appId;
	}

	public UnsignedInt getTipoEntidade() {
		return tipoEntidade;
	}
	
	public TransformGroup getTgAvatar() {
		return tgAvatar;
	}

	public void inicializaEstruturaGrafica() {

		qtdeEntidadesApp = 0;
		tabelaIdEntidadesRemotas.clear();
		tabelaIdTirosRemotos.clear();
		tabelaIdTirosLocais.clear();
		estaAtirando = false;
		
		getProto().getContentPane().remove(canvas3d);

		GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
		universo.removeAllLocales();
		canvas3d = new Canvas3D(config);
		getProto().getContentPane().add(canvas3d, "Center");
		getProto().getContentPane().doLayout();
		// Cria um objeto do tipo SimpleUniverse passando como refer�ncia o
		// objeto do tipo Canvas3D onde ser� projetada a imagem do mundo virtual
		universo = new SimpleUniverse(canvas3d);
		//altera a regiao frontal de corta da proje��o para 0.04m	
		universo.getViewer().getView().setFrontClipDistance(0.04d);
		//pega refer�ncia ao objeto TransformGroup da plataforma de vis�o
		transformGroupDeVisao = universo.getViewingPlatform().getViewPlatformTransform();
		trataTecladoBehavior = new TrataTecladoBehavior(getProto(), transformGroupDeVisao);
		//adiciona objeto da classe TrataTecladoBehavior para ser o tratador
		//do evento de teclas pressionadas qdo o foco estiver sobre o canvas3d
		canvas3d.addKeyListener(trataTecladoBehavior);
		
		//Instancia o BranchGroup principal
		bgRaiz = new BranchGroup();
		//Instancia os BranchGroup's auxiliares
		bgEntidades = new BranchGroup();
		bgTirosLocais = new BranchGroup();
		bgEntidadesRemotas = new BranchGroup();
		bgTirosRemotos = new BranchGroup();

		//Modifica as permiss�es dos BranchGroup's instanciados
		//para permitir que estes possam ser desconectados
		//ap�s terem sido conectados pela primeira vez
		//Isso � necess�rio pois a cria��o e elimina��o dos objetos
		//visuais � feita dinamicamente e depois que um BranchGroup
		//� conectado n�o pode-se alter�-lo a n�o ser que se
		//modifique essas permiss�es
		//Tamb�m seta a permiss�o de CHILDREN_READ para que seja
		//poss�vel ter acesso �s informa��es dos n�s filhos
		bgRaiz.setCapability(BranchGroup.ALLOW_DETACH);
		bgRaiz.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgEntidades.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgTirosLocais.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgEntidadesRemotas.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgTirosRemotos.setCapability(BranchGroup.ALLOW_CHILDREN_READ);

		//BoundingSphere behaveBounds = new BoundingSphere(new Point3d(), 1000.0);
		//Adiciona os BranchGroup's criando a estrutura especificada
		//no grafo de cena
		bgRaiz.addChild(bgEntidades);
		bgRaiz.addChild(bgTirosLocais);
		bgEntidades.addChild(bgTirosRemotos);
		bgEntidades.addChild(bgEntidadesRemotas);
		
		//inicializa alguns atributos
		setUltimaTeclaPressionada("nenhuma");
		setDirecaoColisao("nenhuma");

		//Adiciona o BranchGroup principal no universo
		//A partir desse momento os objetos se tornam "vivos"
		//e passam a ser visualizados(renderizados)
		atachDetachBG("atachar", bgRaiz, null);
	}
	
	public AmbienteVirtual() {
		//construindo a interface gr�fica
		setTitle("Prot�tipo de um Ambiente Virtual Distribu�do Multiusu�rio - TCC 2001/1 - Vandeir Eduardo");
		
		addWindowListener(new WindowAdapter() {
	        public void windowClosing (WindowEvent evt) {
	              System.exit(0);
	    }});

		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		setSize(700, 500);
		GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
		painelEsquerdo = new JPanel();
		painelEsquerdo.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createRaisedBevelBorder(), BorderFactory.createLoweredBevelBorder()));//BorderFactory.createEmptyBorder(10,10,10,10));
		painelEsquerdo.setBorder(BorderFactory.createCompoundBorder(painelEsquerdo.getBorder(), BorderFactory.createEmptyBorder(10,10,10,10)));
		painelEsquerdo.setLayout(new GridLayout(20,1,0,0));
		rbGroup = new ButtonGroup();
		rbCone = new JRadioButton("Cone", true);
		rbCaixa = new JRadioButton("Caixa", false);
		rbCilindro = new JRadioButton("Cilindro", false);
		rbEsfera = new JRadioButton("Esfera", false);
		rbGroup.add(rbCone);
		rbGroup.add(rbCaixa);
		rbGroup.add(rbCilindro);
		rbGroup.add(rbEsfera);
		painelEsquerdo.add(new JLabel("Personagem:"));
		painelEsquerdo.add(rbCone);
		painelEsquerdo.add(rbCaixa);
		painelEsquerdo.add(rbCilindro);
		painelEsquerdo.add(rbEsfera);
		painelEsquerdo.add(new JLabel(""));
		painelEsquerdo.add(new JLabel("Identifa��o:"));
		int temp2 = 0;
		//atribui um n�mero de identifica��o pra aplica��o
		//de acordo com o nome do host
		try {
			InetAddress end = InetAddress.getLocalHost();
			String temp = end.getHostName();
			for (int i = 0; i < temp.length(); i++) {
				Character ch = new Character(temp.charAt(i));
				temp2 = temp2 + ch.getNumericValue(ch.charValue());
			}
		} catch (UnknownHostException uhe) {
			System.out.println("AmbienteVirtual:constructor(): Imposs�vel determinar IP do host local");
		}
		appId = (short)temp2;
		String temp3 = new String("");
		temp3 = temp3 + appId;
		tfId = new JTextField(temp3);
		tfId.setEditable(false);
		painelEsquerdo.add(tfId);
		painelEsquerdo.add(new JLabel(""));
		painelEsquerdo.add(new JLabel("Localiza��o:"));
		tfPosX = new JTextField("0.0");
		tfPosY = new JTextField("0.0");
		tfPosZ = new JTextField("0.0");
		tfPosX.setEditable(false);
		tfPosY.setEditable(false);
		tfPosZ.setEditable(false);
		painelEsquerdo.add(tfPosX);
		painelEsquerdo.add(tfPosY);
		painelEsquerdo.add(tfPosZ);
		painelEsquerdo.add(new JLabel(""));
		btEntrar = new JButton("Entrar");
		//atribui��o de a��o no bot�o Entrar
		btEntrar.addActionListener(new ActionListener () {
	       public void actionPerformed (ActionEvent evt) {
				inicializaEstruturaGrafica();
				btEntrar.setEnabled(false);
				btSair.setEnabled(true);
//				if (!bgRaiz.isLive())
//					atachDetachBG("atachar", bgRaiz, null);
				Short sh = new Short(tfId.getText());
				tm = new TrataMovimentos(getProto(), appId);
				criaAvatar();
				tm.start();
				rbCaixa.setEnabled(false); rbCone.setEnabled(false); rbCilindro.setEnabled(false); rbEsfera.setEnabled(false);
				canvas3d.requestFocus();
			}
	    });
		painelEsquerdo.add(btEntrar);
		btSair = new JButton("Sair");
		btSair.setEnabled(false);
		//atribui��oi de a��o no bot�o Sair
		btSair.addActionListener(new ActionListener () {
	       public void actionPerformed (ActionEvent evt) {
				eliminaAvatar();
				tm.setVivo(false);
				getProto().getContentPane().remove(table);
				infoUsuarios = new PainelInfoUsuarios();
	   		   JTable table = new JTable(infoUsuarios);
    	   			   table.setPreferredScrollableViewportSize(new Dimension(200, 70));
     	    			  JScrollPane scrollPane = new JScrollPane(table);
				getProto().getContentPane().add(scrollPane, "South");
				canvas3d.removeKeyListener(trataTecladoBehavior);
				rbCaixa.setEnabled(true); rbCone.setEnabled(true); rbCilindro.setEnabled(true); rbEsfera.setEnabled(true);
			    btEntrar.setEnabled(true);
				btSair.setEnabled(false);
				tfPosX.setText("0.0");
				tfPosY.setText("0.0");
				tfPosZ.setText("0.0");
				getProto().getContentPane().doLayout();
			}
	    });
		painelEsquerdo.add(btSair);
		painelEsquerdo.add(new JLabel(""));
		btFechar = new JButton("Fechar");
		btFechar.addActionListener(new ActionListener () {
	       public void actionPerformed (ActionEvent evt) {
			    if (bgRaiz != null)
					if (bgRaiz.isLive()){
						eliminaAvatar();	
						tm.setVivo(false);
					}
				bsb.cleanup();
				bsb.shutdown();
				System.exit(0);
			}
	    });
		painelEsquerdo.add(btFechar);
	
		//Chama fun��o para inicializar as apar�ncias
		//que ser�o aplicadas aos objetos visuais na sua cria��o
		inicializaAparencias();

		canvas3d = new Canvas3D(config);
		contentPane.add(canvas3d, "Center");
		contentPane.add(painelEsquerdo, "West");

		infoUsuarios = new PainelInfoUsuarios();
        table = new JTable(infoUsuarios);
        table.setPreferredScrollableViewportSize(new Dimension(200, 70));
        JScrollPane scrollPane = new JScrollPane(table);
		contentPane.add(scrollPane, "South");
		universo = new SimpleUniverse(canvas3d);
//		inicializaEstruturaGrafica();
/*		// Cria um objeto do tipo SimpleUniverse passando como refer�ncia o
		// objeto do tipo Canvas3D onde ser� projetada a imagem do mundo virtual
		universo = new SimpleUniverse(canvas3d);
		//altera a regiao frontal de corta da proje��o para 0.04m	
		universo.getViewer().getView().setFrontClipDistance(0.04d);
		//pega refer�ncia ao objeto TransformGroup da plataforma de vis�o
		transformGroupDeVisao = universo.getViewingPlatform().getViewPlatformTransform();
		trataTecladoBehavior = new TrataTecladoBehavior(getProto(), transformGroupDeVisao);
		//adiciona objeto da classe TrataTecladoBehavior para ser o tratador
		//do evento de teclas pressionadas qdo o foco estiver sobre o canvas3d
		canvas3d.addKeyListener(trataTecladoBehavior);
		
		//Instancia o BranchGroup principal
		bgRaiz = new BranchGroup();
		//Instancia os BranchGroup's auxiliares
		bgEntidades = new BranchGroup();
		bgTirosLocais = new BranchGroup();
		bgEntidadesRemotas = new BranchGroup();
		bgTirosRemotos = new BranchGroup();

		//Modifica as permiss�es dos BranchGroup's instanciados
		//para permitir que estes possam ser desconectados
		//ap�s terem sido conectados pela primeira vez
		//Isso � necess�rio pois a cria��o e elimina��o dos objetos
		//visuais � feita dinamicamente e depois que um BranchGroup
		//� conectado n�o pode-se alter�-lo a n�o ser que se
		//modifique essas permiss�es
		//Tamb�m seta a permiss�o de CHILDREN_READ para que seja
		//poss�vel ter acesso �s informa��es dos n�s filhos
		bgRaiz.setCapability(BranchGroup.ALLOW_DETACH);
		bgRaiz.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgEntidades.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgTirosLocais.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgEntidadesRemotas.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
		bgTirosRemotos.setCapability(BranchGroup.ALLOW_CHILDREN_READ);

		//BoundingSphere behaveBounds = new BoundingSphere(new Point3d(), 1000.0);
		//Adiciona os BranchGroup's criando a estrutura especificada
		//no grafo de cena
		bgRaiz.addChild(bgEntidades);
		bgRaiz.addChild(bgTirosLocais);
		bgEntidades.addChild(bgTirosRemotos);
		bgEntidades.addChild(bgEntidadesRemotas);
		
		//inicializa alguns atributos
		setUltimaTeclaPressionada("nenhuma");
		setDirecaoColisao("nenhuma");*/

		//Adiciona o BranchGroup principal no universo
		//A partir desse momento os objetos se tornam "vivos"
		//e passam a ser visualizados(renderizados)
		//atachDetachBG("atachar", bgRaiz, null);

	}

	AmbienteVirtual getProto(){
		return this;
	}

	//Fun��o respons�vel por inicializar as apar�ncias que ser�o
	//atribu�das a cada uma das faces dos objetos criados
	//Cada apar�ncia recebe uma cor diferente
	void inicializaAparencias() {
		ap1 = new Appearance();
		setaCapacidades(ap1);
		ap1.setColoringAttributes(cor1);

		ap2 = new Appearance();
		setaCapacidades(ap2);
		ap2.setColoringAttributes(cor2);

		ap3 = new Appearance();
		setaCapacidades(ap3);
		ap3.setColoringAttributes(cor3);

		ap4= new Appearance();
		setaCapacidades(ap4);
		ap4.setColoringAttributes(cor4);

		ap5 = new Appearance();
		setaCapacidades(ap5);
		ap5.setColoringAttributes(cor5);

		ap6 = new Appearance();
		setaCapacidades(ap6);
		ap6.setColoringAttributes(cor6);
	}

	//Modifica as permiss�es dos objetos de apar�ncia para
	//que seja poss�vel alterar o modo de exibi��o de
	//normal para aramado e vice-versa
	void setaCapacidades(Appearance ap) {
		ap.setCapability(Appearance.ALLOW_POLYGON_ATTRIBUTES_READ);
		ap.setCapability(Appearance.ALLOW_POLYGON_ATTRIBUTES_WRITE);
		ap.setPolygonAttributes(new PolygonAttributes(1, 1, 0.0f));
	}

	//Fun��o para exibir mensagens em geral
	void exibeMensagem(String msg) {
		JDialog mensagem = new JDialog(this, true);
		mensagem.setLayout(new GridLayout(2,1,0,0));
		mensagem.setSize(300,80);
		mensagem.setLocation(350,250);
		mensagem.add(new JLabel(msg));
		JButton btOK = new JButton("OK");
		btOK.addActionListener(new ActionListener () {
	       public void actionPerformed (ActionEvent evt) {
				JButton bt = (JButton)evt.getSource();
				JDialog dg = (JDialog)bt.getParent();
				dg.dispose();
			}
	    });
		mensagem.add(btOK);
		mensagem.addWindowListener(new WindowAdapter() {
	        public void windowClosing (WindowEvent evt) {
		          evt.getWindow().dispose();
			}
		});
		mensagem.show();
	}

	//utilizado para atualizar a tabela (interface gr�fica) de usu�rios
	void atualizaTabelaEntidades(String applicationID, double[] coord, String acao, String tipoPDU) {
		Vector vector = new Vector();
		vector.addElement(new String(applicationID));
		Float floatTemp = new Float(coord[0]);
		vector.addElement(new String(floatTemp.toString()));
		floatTemp = new Float(coord[1]);
		vector.addElement(new String(floatTemp.toString()));
		floatTemp = new Float(coord[2]);
		vector.addElement(new String(floatTemp.toString()));
		infoUsuarios.updatePlayer(vector, acao, tipoPDU);
	}
	
	//m�todo chamado qdo o usu�rio sai do AV
	//al�m de desatachar o BranchGroup raiz, fazendo
	//com que as imagens do AV parem de ser renderizadas
	//no canvas3D, tb envia em REPDU aos demais
	//usu�rios para que os mesmos removam esse usu�rio
	//de suas representa��es do AV
	void eliminaAvatar() {
		atachDetachBG("desatachar", bgRaiz, null);
		RemoveEntityPdu rePDU = new RemoveEntityPdu();
		rePDU.setOriginatingEntityID(new EntityID(siteId,appId,1));
		bsb.setTimeToLive(15);
		Thread enviadorPDU = new Thread(bsb);
		rePDU.setExemplar(rePDU);
		bsb.sendPdu(rePDU.getExemplar(), endBroadCast, 8133);
		qtdeEntidadesApp--;
	}
	
	//m�todo chamado para criar o avatar respons�vel por representar
	//o usu�rio no AV. Al�m disso tb enviar um CEPDU aos
	//demais usu�rios, para que esses comecem a representar esse
	//novo usu�rio nas suas representa��es do AV
	void criaAvatar() {
		Transform3D t3d = new Transform3D();
		TransformGroup tg = new TransformGroup(t3d);
		tgAvatar = tg;
		//O objeto da classe EntityID ser� anexado ao TransformGroup
		//do avatar, identificando de forma �nica essa entidade no AV
		EntityID entId = new EntityID(siteId, appId, (short)1);
		tg.setUserData(entId);
		//se o usu�rio escolheu um cone
		if (rbCone.isSelected()) {
			Float raio = new Float(0.2f);
			Float altura = new Float(0.4f);
			Cone obj = new Cone(raio.floatValue(), altura.floatValue());
			obj.setAppearance(0, ap1);
			obj.setAppearance(1, ap2);
			//tipoEntidade ser� enviado no CEPDU e servir� para
			//os demais usu�rios saber de que forma geom�trica representar
			//o novo usu�rio (1-Cone, 2-Caixa, 3-Cilindor e 4-Esfera)
			tipoEntidade = new UnsignedInt(1);
			tg.addChild(obj);
		} else {
			//se escolheu uma caixa
			if (rbCaixa.isSelected()) {
				Float largura = new Float(0.2f);
				Float altura = new Float(0.2f);
				Float profundidade = new Float(0.2f);
				com.sun.j3d.utils.geometry.Box obj = new com.sun.j3d.utils.geometry.Box(largura.floatValue(), altura.floatValue(), profundidade.floatValue(), ap1);
				obj.setAppearance(0, ap1);
				obj.setAppearance(1, ap2);
				obj.setAppearance(2, ap3);
				obj.setAppearance(3, ap4);
				obj.setAppearance(4, ap5);
				obj.setAppearance(5, ap6);
				tipoEntidade = new UnsignedInt(2);
				tg.addChild(obj);
			} else {
				//se escolheu um cilindro
				if (rbCilindro.isSelected()) {
					Float raio = new Float(0.2f);
					Float altura = new Float(0.4f);
					Cylinder obj = new Cylinder(raio.floatValue(), altura.floatValue());
					obj.setAppearance(0, ap3);
					obj.setAppearance(1, ap4);
					obj.setAppearance(2, ap5);
					tipoEntidade = new UnsignedInt(3);
					tg.addChild(obj);
				} else {
					//sen�o escolheu uma esfera
					Float raio = new Float(0.2f);
					Sphere obj = new Sphere(raio.floatValue(), ap6);
					tipoEntidade = new UnsignedInt(4);
					tg.addChild(obj);
				}
			}
		}
		ViewerAvatar va = new ViewerAvatar();
		va.addChild(tg);
		qtdeEntidadesApp++;

		//cria e envia um CEPDU aos demais usu�rio a fim de informar
		//acerca da entrada desse novo usu�rio
		CreateEntityPdu cePDU = new CreateEntityPdu();
		cePDU.setOriginatingEntityID(new EntityID(siteId,appId,qtdeEntidadesApp));
		cePDU.setRequestID(tipoEntidade.longValue());
		bsb.setTimeToLive(15);
		Thread enviadorPDU = new Thread(bsb);
		cePDU.setExemplar(cePDU);
		bsb.sendPdu(cePDU.getExemplar(), endBroadCast, 8133);

		//cria e associa o objeto da classe HeartBeatBehavior
		myHeartBeatBehavior = new HeartBeatBehavior(transformGroupDeVisao, getProto());
		myHeartBeatBehavior.setSchedulingBounds(new BoundingSphere(new Point3d(0, 0, 0), 40));
		va.addChild(myHeartBeatBehavior);
		
		//cria e associa o objeto da classe CollisionBehavior
		CollisionBehavior myCollisionBehavior = new CollisionBehavior(getProto(), tg);
		myCollisionBehavior.setSchedulingBounds(new BoundingSphere(/*new Point3d(0, 0, 0), 2*/));
		va.addChild(myCollisionBehavior);
		
		//adiciona o avatar ao objeto da classe Viewer da plataforma de vis�o
		universo.getViewer().setAvatar(va);
	}
	
	//M�todo chamado qdo a aplica��o recebe um PDU do tipo CreateEntityPDU
	void criaEntidadeRemota(CreateEntityPdu cePDU, double[] coordenadas, long tipo) {
		Transform3D t3d = new Transform3D();
		t3d.setTranslation(new Vector3d(coordenadas[0], coordenadas[1], coordenadas[2]));
		TransformGroup tg = new TransformGroup(t3d);
		//verifica qual o tipo de entidade a ser criada (1-Cone, 2-Caixa, 3-Cilindor e 4-Esfera)
		if (tipo == 1) {
			Float raio = new Float(0.2f);
			Float altura = new Float(0.4f);
			Cone obj = new Cone(raio.floatValue(), altura.floatValue());
			obj.setAppearance(0, ap1);
			obj.setAppearance(1, ap2);
			tg.addChild(obj);
		} else {
			if (tipo == 2) {
				Float largura = new Float(0.2f);
				Float altura = new Float(0.2f);
				Float profundidade = new Float(0.2f);
				com.sun.j3d.utils.geometry.Box obj = new com.sun.j3d.utils.geometry.Box(largura.floatValue(), altura.floatValue(), profundidade.floatValue(), ap1);
				obj.setAppearance(0, ap1);
				obj.setAppearance(1, ap2);
				obj.setAppearance(2, ap3);
				obj.setAppearance(3, ap4);
				obj.setAppearance(4, ap5);
				obj.setAppearance(5, ap6);
				tg.addChild(obj);
			} else {
				if (tipo == 3) {
					Float raio = new Float(0.2f);
					Float altura = new Float(0.4f);
					Cylinder obj = new Cylinder(raio.floatValue(), altura.floatValue());
					obj.setAppearance(0, ap3);
					obj.setAppearance(1, ap4);
					obj.setAppearance(2, ap5);
					tg.addChild(obj);
				} else {
					Float raio = new Float(0.2f);
					Sphere obj = new Sphere(raio.floatValue(), ap6);
					tg.addChild(obj);
				}
			}
		}

		//adiciona um n�mero 2D � entidade de forma que seja poss�vel visualiz�-lo
		//no AV
		Short numIdent = new Short(cePDU.getOriginatingEntityID().getApplicationID().shortValue());
		Text2D text2d = new Text2D (numIdent.toString(), new Color3f(0.4f, 0.6f, 0.3f), "Helvetica", 18, Font.PLAIN);
		tg.addChild(text2d);

		//seta permiss�es que permitem efetuar transforma��es sobre
		//o objeto visual mesmo qdo est� vivo
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		//seta permiss�es que fazem com que esse objeto seja
		//reportado por m�todos como getTriggeringPath(), de forma
		//que seja poss�vel acess�-lo no caso de colis�es
		tg.setCapability(TransformGroup.ENABLE_PICK_REPORTING);
		tg.setCapability(TransformGroup.ENABLE_COLLISION_REPORTING);

		EntityID entId = new EntityID();
		entId = (EntityID)cePDU.getOriginatingEntityID().clone();
		tg.setUserData(entId);

		//desatacha BranchGroup raiz para que seja poss�vel adicionar
		//a entidade ao cen�rio
		atachDetachBG("desatachar", bgRaiz, null);
		//adiciona a identifica��o dessa entidade na tabela de entidades remotas
		tabelaIdEntidadesRemotas.add(entId);
		//adiciona essa entidade no BranchGroup de entidades remotas
		bgEntidadesRemotas.insertChild(tg, tabelaIdEntidadesRemotas.size()-1);
		//atacha novamente o BranchGroup raiz, a partir desse momento a imagem da nova
		//entidade j� come�a a ser renderizada no canvas3d
		atachDetachBG("atachar", bgRaiz, bgEntidades);
		//atualiza a tabela (interface gr�fica) de usu�rios
		//nesse caso uma nova linha ser� acrescentada � tabela
		atualizaTabelaEntidades(entId.getApplicationID().toString(), coordenadas, "Adicionar", "CEPDU");
	}
	
	//m�todo chamado qdo a entidade local dispara um tiro
	void criaTiroLocal(FirePdu frPDU) {
		//os tiros s�o representados por esferas...
		Float raio = new Float(0.1f);
		Sphere objEsfera = new Sphere(raio.floatValue(), ap6);
		//pega as coordenadas do tiro no FirePDU
		double tiroPosicaoX = frPDU.getLocationInWorldCoordinate().getX();
		double tiroPosicaoY = frPDU.getLocationInWorldCoordinate().getY();
		double tiroPosicaoZ = frPDU.getLocationInWorldCoordinate().getZ();
		Transform3D t3d = new Transform3D();
		t3d.setTranslation(new Vector3d(tiroPosicaoX, tiroPosicaoY, tiroPosicaoZ));
		TransformGroup tg = new TransformGroup(t3d);
		tg.addChild(objEsfera);
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		tg.setCapability(TransformGroup.ENABLE_COLLISION_REPORTING);
		
		EntityID entId = new EntityID();
		//pega a identifica��o que identifica de forma �nica o tiro no AV
		entId = (EntityID)frPDU.getFiringEntityID().clone();
		qtdeEntidadesApp++;
		tg.setUserData(entId);

		atachDetachBG("desatachar", bgRaiz, null);
		//adiciona o comportamento AnimaTiroBehavior no TransformGroup do
		//tiro local. Esse comportamento � que ser� o respons�vel por gerar
		//a anima��o (deslocamento) do tiro
		AnimaTiroBehavior myAnimaTiroBehavior = new AnimaTiroBehavior(getProto(), tg);
		myAnimaTiroBehavior.setSchedulingBounds(new BoundingSphere(new Point3d(tiroPosicaoX, tiroPosicaoY, tiroPosicaoZ), 0.2));
		tg.addChild(myAnimaTiroBehavior);
		//adiciona identifica��o do tiro na tabela de tiros locais
		tabelaIdTirosLocais.add(entId);
		//adiciona o tiro no BranchGroup de tiros locais
		bgTirosLocais.insertChild(tg, tabelaIdTirosLocais.size()-1);

		atachDetachBG("atachar", bgRaiz, bgRaiz);
	}

	//m�todo chamado como conseq��ncia do recebimento de um
	//FirePDU, indicando o disparo realizado por uma entidade remota.
	//L�gica de funcionamento semelhante ao criaTiroLocal, s� que
	//a identifica��o da tiro � inserida na tabela de tiros remotos e
	//a entidade � inserida no BranchGroup de tiro remotos.
	//No caso de um tiro remoto, a esse n�o � adicionado o comportamento
	//AnimaTiroBehavior. A anima��o dos tiros remotos � feita pelo
	//recebimento de ESPDU's que informam a sua mudan�a de posi��o
	void criaTiroRemoto(FirePdu frPDU) {
		Float raio = new Float(0.1f);
		Sphere objEsfera = new Sphere(raio.floatValue(), ap6);
		double tiroPosicaoX = frPDU.getLocationInWorldCoordinate().getX();
		double tiroPosicaoY = frPDU.getLocationInWorldCoordinate().getY();
		double tiroPosicaoZ = frPDU.getLocationInWorldCoordinate().getZ();
		Transform3D t3d = new Transform3D();
		t3d.setTranslation(new Vector3d(tiroPosicaoX, tiroPosicaoY, tiroPosicaoZ));
		TransformGroup tg = new TransformGroup(t3d);
		tg.addChild(objEsfera);
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		tg.setCapability(TransformGroup.ENABLE_COLLISION_REPORTING);
		EntityID entId = new EntityID();
		entId = (EntityID)frPDU.getFiringEntityID().clone();
		qtdeEntidadesApp++;
		tg.setUserData(entId);

		atachDetachBG("desatachar", bgRaiz, null);

		tabelaIdTirosRemotos.add(entId);
		bgTirosRemotos.insertChild(tg, tabelaIdTirosRemotos.size()-1);

		atachDetachBG("atachar", bgRaiz, bgEntidades);

		double[] coordenadas = new double[3];
		atualizaTabelaEntidades(entId.getApplicationID().toString(), coordenadas, "NaoAtualizarCoordenadas", "FRPDU");
	}

	//m�todo chamado como conseq��ncia do recebimento de um 
	//RemoveEntityPDU enviado por outro usu�rio
	void removeEntidade(RemoveEntityPdu rePDU) {
		//pega a identifica��o da entidade a ser removida
		long origSiteId = rePDU.getOriginatingEntityID().getSiteID().longValue();
		long origAppId = rePDU.getOriginatingEntityID().getApplicationID().longValue();
		long origEntityId = rePDU.getOriginatingEntityID().getEntityID().longValue();
		int entityId = 0;
		String achou = "false";
		System.out.println("AmbienteVirtual:removeEntidade(): Entidade a ser removida: Site "+origSiteId+" Aplica��o "+origAppId+" Entidade "+origEntityId);
		EntityID entID = new EntityID();
		int i = 0;
		//procura identifica��o da entidade na tabela de tiros remotos
		while ((i < tabelaIdTirosRemotos.size()) && (achou == "false")){
			entID = (EntityID)tabelaIdTirosRemotos.get(i);
			if (((entID.getSiteID().longValue() == origSiteId) && (entID.getApplicationID().longValue() == origAppId)) && (entID.getEntityID().longValue() == origEntityId)) {
				System.out.println("AmbienteVirtual:removeEntidade(): Encontrou entidade do tipo Tiro Remoto");
				achou = "tiroRemoto";
				entityId = i;
				if (origEntityId > 1)
					qtdeEntidadesApp--;
			}
			i++;
		}
		//procura identifica��o da entidade na tabela de tiros locais
		if (achou == "false"){
			i = 0;
			while ((i < tabelaIdTirosLocais.size()) && (achou == "false")){
				entID = (EntityID)tabelaIdTirosLocais.get(i);
				if (((entID.getSiteID().longValue() == origSiteId) && (entID.getApplicationID().longValue() == origAppId)) && (entID.getEntityID().longValue() == origEntityId)) {
					System.out.println("AmbienteVirtual:removeEntidade(): Encontrou entidade do tipo Tiro Local");
					achou = "tiroLocal";
					entityId = i;
					if (origEntityId > 1)
						qtdeEntidadesApp--;
				}
				i++;
			}
		}
		//procura identifica��o da entidade na tabela de entidades remotas
		if (achou == "false"){
			i = 0;
			while ((i < tabelaIdEntidadesRemotas.size()) && (achou == "false")){
				entID = (EntityID)tabelaIdEntidadesRemotas.get(i);
				if (((entID.getSiteID().longValue() == origSiteId) && (entID.getApplicationID().longValue() == origAppId)) && (entID.getEntityID().longValue() == origEntityId)) {
					System.out.println("AmbienteVirtual:removeEntidade(): Encontrou entidade do tipo Entidade Remota");
					achou = "entidadeRemota";
					entityId = i;
					if (origEntityId > 1)
						qtdeEntidadesApp--;
				}
				i++;
			}
		}

		double[] coord = new double[3];
		//se for a remo��o de uma entidade do tipo remota � preciso
		//atualizar a tabela (interface gr�fica), removendo a linha
		//correspondente ao usu�rio
		if (origEntityId == 1) {
			atualizaTabelaEntidades(rePDU.getOriginatingEntityID().getApplicationID().toString(), coord, "Remover", "REPDU");
		} else {
			//sen�o s� atualiza, contabilizando o recebimento de um REPDU
			if (origAppId != appId) {
				atualizaTabelaEntidades(rePDU.getOriginatingEntityID().getApplicationID().toString(), coord, "NaoAtualizarCoordenadas", "REPDU");
			}
		}
		//se for um tiro remoto, elimina a identifica��o da tabela de
		//tiros remotos e a entidade do BranchGroup de tiros remotos
		if (achou == "tiroRemoto") {
			atachDetachBG("desatachar", bgRaiz, null);
			bgTirosRemotos.removeChild(entityId);
			tabelaIdTirosRemotos.remove(entityId);
			atachDetachBG("atachar", bgRaiz, bgEntidades);
		} else {
			//se for um tiro local, elimina a identifica��o da tabela de
			//tiros locais e a entidade do BranchGroup de tiros locais
			if (achou == "tiroLocal") {
				atachDetachBG("desatachar", bgRaiz, null);
				bgTirosLocais.removeChild(entityId);
				tabelaIdTirosLocais.remove(entityId);
				atachDetachBG("atachar", bgRaiz, bgRaiz);
			//sen�o elimina a identifica��o da tabela de
			//entidades remotas e a entidade do BranchGroup de entidades remotas
			} else {
				atachDetachBG("desatachar", bgRaiz, null);
				bgEntidadesRemotas.removeChild(entityId);
				tabelaIdEntidadesRemotas.remove(entityId);
				atachDetachBG("atachar", bgRaiz, bgEntidades);
			}
		}
	}
	
	//m�todo chamado como conseq��ncia do recebimento de um
	//EntityStadePDU, com a finalidade de aplicacar a nova
	//localiza��o � entidade que est� sendo movimentada por outro usu�rio
	void transladaEntidade(EntityStatePdu esPDU) {
		double[] coordenadas = new double[3];
		coordenadas[0] = esPDU.getEntityLocationX();
		coordenadas[1] = esPDU.getEntityLocationY();
		coordenadas[2] = esPDU.getEntityLocationZ();
		long origSiteId = esPDU.getEntityID().getSiteID().longValue();
		long origAppId = esPDU.getEntityID().getApplicationID().longValue();
		long origEntityId = esPDU.getEntityID().getEntityID().longValue();
		System.out.println("AmbienteVirtual:transladaEntidade(): Movimentar entidade "+origEntityId+" da aplica��o: "+origAppId+" para as coordenadas X: "+coordenadas[0]+" Y: "+coordenadas[1]+" Z: "+coordenadas[2]);
		int entityId = 0;
		String achou = "false";
		EntityID entID = new EntityID();
		int i = 0;
		//procura ID da entidade na tabela de tiros remotos
		while ((i < tabelaIdTirosRemotos.size()) && (achou == "false")){
			entID = (EntityID)tabelaIdTirosRemotos.get(i);
			if (((entID.getSiteID().longValue() == origSiteId) && (entID.getApplicationID().longValue() == origAppId)) && (entID.getEntityID().longValue() == origEntityId)) {
				achou = "tiroRemoto";
				entityId = i;
			}
			i++;
		}
		//procura ID da entidade na tabela de tiros locais
		if (achou == "false"){
			i = 0;
			while ((i < tabelaIdTirosLocais.size()) && (achou == "false")){
				entID = (EntityID)tabelaIdTirosLocais.get(i);
				if (((entID.getSiteID().longValue() == origSiteId) && (entID.getApplicationID().longValue() == origAppId)) && (entID.getEntityID().longValue() == origEntityId)) {
					achou = "tiroLocal";
					entityId = i;
				}
				i++;
			}
		}
		//procura ID da entidada de tabela de entidades remotas
		if (achou == "false"){
			i = 0;
			while ((i < tabelaIdEntidadesRemotas.size()) && (achou == "false")){
				entID = (EntityID)tabelaIdEntidadesRemotas.get(i);
				if (((entID.getSiteID().longValue() == origSiteId) && (entID.getApplicationID().longValue() == origAppId)) && (entID.getEntityID().longValue() == origEntityId)) {
					achou = "entidadeRemota";
					entityId = i;
				}
				i++;
			}
		}
		//se n�o achou ID da entidade em nenhuma tabela cria essa entidade
		if (achou == "false") {
			long entApp = esPDU.getEntityAppearance().longValue();
			CreateEntityPdu cePDU = new CreateEntityPdu();
			cePDU.setOriginatingEntityID(new EntityID((short)origSiteId,(short)origAppId,(short)1));
			criaEntidadeRemota(cePDU, coordenadas, entApp);
			return;
		}
		//atualiza a tabela (interface gr�fica) de usu�rios
		//contabilizando o recebimento de um ESPDU
		if (origEntityId == 1) {
			atualizaTabelaEntidades(esPDU.getEntityID().getApplicationID().toString(), coordenadas, "Atualizar", "ESPDU");
		} else {
			atualizaTabelaEntidades(esPDU.getEntityID().getApplicationID().toString(), coordenadas, "NaoAtualizarCoordenadas", "ESPDU");
		}
		if (achou == "tiroRemoto")
			tgAux = (TransformGroup) bgTirosRemotos.getChild(entityId);
		else if (achou == "tiroLocal")
				tgAux = (TransformGroup) bgTirosLocais.getChild(entityId);
			else
				tgAux = (TransformGroup) bgEntidadesRemotas.getChild(entityId);
		//aplica as novas coordenadas � entidade
		tgAux.getTransform(t3dAux);
		t3dAux.setTranslation(new Vector3d(esPDU.getEntityLocationX(), esPDU.getEntityLocationY(), esPDU.getEntityLocationZ()));
		tgAux.setTransform(t3dAux);
	}		

	//Fun��o principal que instancia e automaticamente
	//chama a fun��o construtora da classe AmbienteVirtual
	//A classe AmbienteVirtual herda a classe JFrame. O "frame"
	//resultante �, ent�o, exibido
	public static void main(String[] args) {
		AmbienteVirtual App = new AmbienteVirtual();
		App.setVisible(true);
	}
}
